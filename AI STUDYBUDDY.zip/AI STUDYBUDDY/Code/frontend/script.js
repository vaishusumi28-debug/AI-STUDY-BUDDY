let selectedFile = null;


/* REGISTER */

function openRegister() {
    closeModals();
    document.getElementById("registerModal").style.display = "flex";
}


function registerUser() {

    const name = document.getElementById("registerName").value.trim();
    const email = document.getElementById("registerEmail").value.trim();
    const password = document.getElementById("registerPassword").value;

    if (!name || !email || !password) {
        alert("Please fill all the fields.");
        return;
    }

    if (password.length < 6) {
        alert("Password must contain at least 6 characters.");
        return;
    }

    const user = {
        name: name,
        email: email,
        password: password
    };

    localStorage.setItem("studyBuddyUser", JSON.stringify(user));

    alert("Registration successful! 🎉");

    closeModals();

    document.getElementById("registerName").value = "";
    document.getElementById("registerEmail").value = "";
    document.getElementById("registerPassword").value = "";
}


/* LOGIN */

function openLogin() {
    closeModals();
    document.getElementById("loginModal").style.display = "flex";
}


function loginUser() {

    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value;

    const savedUser = JSON.parse(
        localStorage.getItem("studyBuddyUser")
    );

    if (!savedUser) {
        alert("No account found. Please register first.");
        return;
    }

    if (
        email === savedUser.email &&
        password === savedUser.password
    ) {

        localStorage.setItem("loggedIn", "true");

        alert("Login successful! Welcome " + savedUser.name + " 🤖");

        closeModals();

    } else {

        alert("Incorrect email or password.");

    }
}


/* CLOSE MODALS */

function closeModals() {

    document.getElementById("registerModal").style.display = "none";
    document.getElementById("loginModal").style.display = "none";

}


/* FILE SELECTION */

document.getElementById("fileInput").addEventListener(
    "change",
    function () {

        selectedFile = this.files[0];

        if (!selectedFile) {
            return;
        }

        document.getElementById("fileName").innerHTML =
            "📄 " + selectedFile.name;

        document.getElementById("verification").innerHTML =
            "🔍 File selected. Ready for verification.";

        document.getElementById("processBtn").disabled = false;

    }
);


/* VERIFY + UPLOAD */

function processFile() {

    if (!selectedFile) {
        alert("Please choose a file first.");
        return;
    }

    const allowedTypes = [
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "text/plain"
    ];

    const maxSize = 10 * 1024 * 1024;

    document.getElementById("verification").innerHTML =
        "⏳ Verifying your study material...";

    setTimeout(function () {

        if (!allowedTypes.includes(selectedFile.type)) {

            document.getElementById("verification").innerHTML =
                "❌ Verification failed: Unsupported file type.";

            return;
        }


        if (selectedFile.size > maxSize) {

            document.getElementById("verification").innerHTML =
                "❌ Verification failed: File must be below 10 MB.";

            return;
        }


        document.getElementById("verification").innerHTML =
            "✅ File verified successfully!";


        saveMaterial(selectedFile);

    }, 1500);
}


/* SAVE MATERIAL */

function saveMaterial(file) {

    let materials = JSON.parse(
        localStorage.getItem("studyMaterials")
    ) || [];


    const material = {

        name: file.name,

        size:
            (file.size / 1024 / 1024)
            .toFixed(2) + " MB",

        type: file.type,

        date: new Date().toLocaleString()

    };


    materials.push(material);

    localStorage.setItem(
        "studyMaterials",
        JSON.stringify(materials)
    );


    displayMaterials();

    alert(
        "🎉 " +
        file.name +
        " uploaded successfully!"
    );

    document.getElementById("processBtn").disabled = true;

}


/* DISPLAY MATERIALS */

function displayMaterials() {

    const materials =
        JSON.parse(
            localStorage.getItem("studyMaterials")
        ) || [];


    const list =
        document.getElementById("materialsList");


    document.getElementById("uploadCount").innerText =
        materials.length;


    if (materials.length === 0) {

        list.innerHTML =
            '<p class="empty-message">No materials uploaded yet.</p>';

        return;

    }


    list.innerHTML = "";


    materials.forEach(function(material, index) {

        const div =
            document.createElement("div");

        div.className = "material";

        div.innerHTML = `
            <div>
                📄 <strong>${material.name}</strong>
                <br>
                <small>${material.size} • ${material.date}</small>
            </div>

            <div>
                <span>✅ Verified</span>
            </div>
        `;

        list.appendChild(div);

    });

}


/* PAGE LOAD */

window.addEventListener(
    "load",
    function () {

        displayMaterials();

    }
);


/* PARALLAX EFFECT */

window.addEventListener(
    "scroll",
    function () {

        const scrollValue = window.scrollY;

        const circles =
            document.querySelectorAll(
                ".floating-circle"
            );


        circles.forEach(
            function(circle, index) {

                const speed =
                    (index + 1) * 0.08;

                circle.style.transform =
                    `translateY(${scrollValue * speed}px)`;

            }
        );

    }
);